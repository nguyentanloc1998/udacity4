export const AUTH0_DOMAIN='dev-8rmszyn2vgwgt44w.jp.auth0.com'
export const AUTH0_CLIENT_ID='S1rlWiuHzb6dXIjWh764vRjVFbt0nIEf'
export const AUTH0_AUDIENCE=`https://dev-8rmszyn2vgwgt44w.jp.auth0.com/api/v2/`
export const API_DESTINATION=`https://j25cx3zu9g.execute-api.us-east-1.amazonaws.com/dev`